package ifpr.pgua.eic.tads.contatos;



/**
 * Unit test for simple App.
 */
public class AppTest 
{


}
